
This directory contains MNIST handwritten digits data:

http://yann.lecun.com/exdb/mnist/

Specifically, the directory contains the files

train-images-idx3-ubyte
train-labels-idx1-ubyte

downloaded from that site. It also contains some functions
for easily reading the data into Matlab/Octave/R and 
displaying the digits and their labels.

The files are provided here to help the students of the
Introduction to Machine Learning course quickly get started 
analyzing the data without having to figure out the details
of the data format and how to display the digits. 

The files are provided exclusively for the above purpose.
Do not distribute.

 
